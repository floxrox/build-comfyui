if __name__ == "__main__":
    from img2texture import cli
    cli()
