__version__ = "1.0.6"

__copyright__ = "(c) Artsiom iG <ortemeo@gmail.com>"
__license__ = "MIT"
__build_timestamp__ = "2022-10-12 05:30:19"

