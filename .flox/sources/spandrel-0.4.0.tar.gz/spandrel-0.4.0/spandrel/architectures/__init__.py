"""
The package containing the implementations of all supported architectures. Not necessary for most user code.
"""

__docformat__ = "google"
